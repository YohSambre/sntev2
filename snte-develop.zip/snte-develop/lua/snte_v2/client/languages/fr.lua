local LANG = {
    ["config_1"] = "Le language à utiliser sur SNTE",
    ["config_2"] = "a",
    ["config_3"] = "a",

}

SNTE_V2.RegisterTranslation("fr", LANG)
